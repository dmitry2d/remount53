jQuery(document).ready(function($) {
  // JavaScript goes here
});
